import java.util.ArrayList;

/**
 * Created by Loïc on 06/01/2017.
 */
public interface IAptitude {

    public void utilise(ArrayList<Vaisseau> vaisseaux);
}
