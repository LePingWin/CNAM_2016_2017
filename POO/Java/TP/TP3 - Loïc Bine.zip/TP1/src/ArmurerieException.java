/**
 * Created by Loïc on 18/11/2016.
 */
public class ArmurerieException extends Exception {

    public ArmurerieException(){
    }

    public ArmurerieException(String message){
        super(message);
    }
}
