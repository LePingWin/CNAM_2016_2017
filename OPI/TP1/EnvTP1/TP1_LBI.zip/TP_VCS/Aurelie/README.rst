.. vim: set spelllang=fr ts=4 sw=4 expandtab:

Documentation sur le format restructuredText:
 - http://docutils.sourceforge.net/docs/user/rst/quickref.html
 - http://docutils.sourceforge.net/docs/ref/rst/directives.html

.. header::

    .. list-table::
      :class: headertable

      * - LBI
        - .. class:: right

          17/11/2016